# MyHelper (Fabric 1.16.5)

Клиентский мод с системой модулей, темами меню, AutoSprint и Zoom.

## Возможности

- **Module system** — Combat / Player / Visuals / Misc
- **Темы** — Fire, Magenta, Marine, Intergalactic
- **AutoSprint** — автоматический спринт
- **Zoom** — удержание клавиши C (по умолчанию)
- **Меню** — Right Shift (по умолчанию)

Модули (Triggerbot, Backtrack, TargetESP и т.д.) добавлены как заглушки — логику можно дописать в соответствующих классах / `onTick()`.

## Сборка

Требования: JDK 8+, Git.

```bash
./gradlew build
```

Готовый jar появится в `build/libs/myhelper-0.2.0.jar`.

## Управление

| Клавиша          | Действие              |
|------------------|-----------------------|
| Right Shift      | Открыть меню          |
| C (hold)         | Zoom                  |

Конфиг сохраняется в `.minecraft/config/myhelper.json`.

## Структура

```
dev.myhelper
├── MyHelperClient
├── config/ModConfig
├── feature/
│   ├── Module, ModuleManager, Theme
│   ├── AutoSprint, AutoSprintModule
│   ├── Zoom, ZoomModule
└── gui/MenuScreen
```
