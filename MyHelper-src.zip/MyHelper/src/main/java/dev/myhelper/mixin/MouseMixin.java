package dev.myhelper.mixin;

import dev.myhelper.feature.Zoom;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MouseMixin {

    /**
     * Reduces mouse sensitivity while zoomed for smoother aiming.
     */
    @Inject(method = "updateMouse", at = @At("HEAD"))
    private void myhelper$onUpdateMouse(CallbackInfo ci) {
        // placeholder – real sensitivity scaling can be added later
        if (Zoom.isActive()) {
            // no-op for now
        }
    }
}
