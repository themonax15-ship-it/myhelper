package dev.myhelper.mixin;

import dev.myhelper.feature.Zoom;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {

    /**
     * Optional FOV hook. Main zoom logic currently lives in Zoom.tick via options.fov.
     * Kept for compatibility / future smooth zoom.
     */
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void myhelper$modifyFov(CallbackInfoReturnable<Double> cir) {
        if (Zoom.isActive()) {
            // already applied via options, but can force here if needed
            // cir.setReturnValue(cir.getReturnValue() * Zoom.getZoomFactor());
        }
    }
}
