package dev.myhelper;

import dev.myhelper.config.ModConfig;
import dev.myhelper.feature.AutoSprint;
import dev.myhelper.feature.ModuleManager;
import dev.myhelper.feature.Zoom;
import dev.myhelper.gui.MenuScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class MyHelperClient implements ClientModInitializer {
    public static final String CATEGORY = "key.categories.myhelper";
    public static ModuleManager moduleManager;

    private static KeyBinding menuKey;
    private static KeyBinding zoomKey;

    @Override
    public void onInitializeClient() {
        ModConfig.get(); // load early
        moduleManager = new ModuleManager();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.myhelper.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                CATEGORY
        ));

        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.myhelper.zoom",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_C,
                CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.openScreen(new MenuScreen(null));
                }
            }

            AutoSprint.tick(client);
            Zoom.tick(client, zoomKey.isPressed());
            moduleManager.tick();
        });
    }

    public static KeyBinding getZoomKey() {
        return zoomKey;
    }
}
