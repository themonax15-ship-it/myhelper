package dev.myhelper.gui;

import dev.myhelper.MyHelperClient;
import dev.myhelper.config.ModConfig;
import dev.myhelper.feature.Module;
import dev.myhelper.feature.Theme;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;

import java.util.List;

public class MenuScreen extends Screen {
    private static final int PANEL_W = 420;
    private static final int PANEL_H = 260;
    private static final int SIDEBAR_W = 110;

    private final Screen parent;
    private String currentCategory = "Combat";
    private Theme currentTheme;

    private int px;
    private int py;

    private static final String[] CATEGORIES = {"Combat", "Player", "Visuals", "Misc"};

    public MenuScreen(Screen parent) {
        super(new LiteralText("MyHelper Menu"));
        this.parent = parent;
        try {
            currentTheme = Theme.valueOf(ModConfig.get().theme);
        } catch (Exception e) {
            currentTheme = Theme.MARINE;
        }
    }

    @Override
    protected void init() {
        px = (this.width - PANEL_W) / 2;
        py = (this.height - PANEL_H) / 2;

        // Category buttons (sidebar)
        int cy = py + 28;
        for (String cat : CATEGORIES) {
            final String category = cat;
            this.addButton(new ButtonWidget(px + 8, cy, SIDEBAR_W - 16, 20,
                    new LiteralText(cat),
                    btn -> currentCategory = category));
            cy += 24;
        }

        // Theme buttons
        int tx = px + SIDEBAR_W + 12;
        for (Theme theme : Theme.values()) {
            final Theme t = theme;
            this.addButton(new ButtonWidget(tx, py + PANEL_H - 28, 70, 18,
                    new LiteralText(theme.getDisplayName()),
                    btn -> {
                        currentTheme = t;
                        ModConfig.get().theme = t.name();
                        ModConfig.get().save();
                    }));
            tx += 74;
        }

        // Close
        this.addButton(new ButtonWidget(px + PANEL_W - 70, py + 6, 60, 18,
                new LiteralText("Close"),
                btn -> onClose()));
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        this.renderBackground(matrices);

        // Main panel background
        int bg = currentTheme.getSecondaryColor() | 0xE0000000;
        fill(matrices, px, py, px + PANEL_W, py + PANEL_H, bg);

        // Sidebar
        int sidebarCol = darken(currentTheme.getSecondaryColor(), 0.25f) | 0xF0000000;
        fill(matrices, px, py, px + SIDEBAR_W, py + PANEL_H, sidebarCol);

        // Accent line
        fill(matrices, px + SIDEBAR_W, py, px + SIDEBAR_W + 2, py + PANEL_H, currentTheme.getPrimaryColor() | 0xFF000000);

        // Title
        drawCenteredText(matrices, this.textRenderer, "MyHelper", px + PANEL_W / 2, py + 8, 0xFFFFFFFF);

        // Category highlight indicator
        int cy = py + 28;
        for (String cat : CATEGORIES) {
            if (cat.equals(currentCategory)) {
                fill(matrices, px + 4, cy, px + SIDEBAR_W - 4, cy + 20, currentTheme.getPrimaryColor() | 0x66000000);
            }
            cy += 24;
        }

        // Modules of current category
        List<Module> mods = MyHelperClient.moduleManager.getModulesByCategory(currentCategory);
        int my = py + 36;
        int mx = px + SIDEBAR_W + 14;

        for (Module mod : mods) {
            boolean on = mod.isToggled();
            int btnColor = on ? (currentTheme.getPrimaryColor() | 0xFF000000) : 0xFF333333;
            int textColor = on ? 0xFFFFFFFF : 0xFFAAAAAA;

            // module button background
            fill(matrices, mx, my, mx + 260, my + 20, btnColor);

            // border
            int border = darken(currentTheme.getPrimaryColor(), 0.4f) | 0xFF000000;
            fill(matrices, mx, my, mx + 260, my + 1, border);
            fill(matrices, mx, my + 19, mx + 260, my + 20, border);

            String label = (on ? "[ON]  " : "[OFF] ") + mod.getName();
            this.textRenderer.drawWithShadow(matrices, label, mx + 6, my + 6, textColor);

            my += 24;
            if (my > py + PANEL_H - 50) break;
        }

        // Theme label
        this.textRenderer.drawWithShadow(matrices, "Theme:", px + SIDEBAR_W + 14, py + PANEL_H - 42, 0xFFCCCCCC);

        super.render(matrices, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Module toggle clicks (custom area)
        if (button == 0) {
            List<Module> mods = MyHelperClient.moduleManager.getModulesByCategory(currentCategory);
            int my = py + 36;
            int mx = px + SIDEBAR_W + 14;

            for (Module mod : mods) {
                if (mouseX >= mx && mouseX <= mx + 260 && mouseY >= my && mouseY <= my + 20) {
                    mod.toggle();
                    MyHelperClient.moduleManager.saveStates();
                    return true;
                }
                my += 24;
                if (my > py + PANEL_H - 50) break;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void onClose() {
        MyHelperClient.moduleManager.saveStates();
        this.client.openScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static int darken(int argb, float factor) {
        int a = (argb >> 24) & 0xFF;
        int r = (int) (((argb >> 16) & 0xFF) * (1.0f - factor));
        int g = (int) (((argb >> 8) & 0xFF) * (1.0f - factor));
        int b = (int) ((argb & 0xFF) * (1.0f - factor));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
