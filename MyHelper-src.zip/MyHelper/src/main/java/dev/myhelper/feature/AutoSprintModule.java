package dev.myhelper.feature;

import dev.myhelper.config.ModConfig;

public class AutoSprintModule extends Module {
    public AutoSprintModule() {
        super("AutoSprint", "Player", 0);
        setToggled(ModConfig.get().autoSprint);
    }

    @Override
    public void onEnable() {
        ModConfig.get().autoSprint = true;
        ModConfig.get().save();
    }

    @Override
    public void onDisable() {
        ModConfig.get().autoSprint = false;
        ModConfig.get().save();
    }
}
