package dev.myhelper.feature;

import dev.myhelper.config.ModConfig;

/**
 * Zoom is primarily hold-to-activate via keybind.
 * This module entry exists so it appears in the menu and can be enabled/disabled.
 */
public class ZoomModule extends Module {
    public ZoomModule() {
        super("Zoom", "Visuals", 0);
        setToggled(ModConfig.get().zoomEnabled);
    }

    @Override
    public void onEnable() {
        ModConfig.get().zoomEnabled = true;
        ModConfig.get().save();
    }

    @Override
    public void onDisable() {
        ModConfig.get().zoomEnabled = false;
        ModConfig.get().save();
    }
}
