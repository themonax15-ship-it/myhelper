package dev.myhelper.feature;

public class Module {
    private final String name;
    private final String category;
    private boolean toggled;
    private int key;

    public Module(String name, String category, int key) {
        this.name = name;
        this.category = category;
        this.key = key;
        this.toggled = false;
    }

    public void toggle() {
        setToggled(!toggled);
    }

    public void setToggled(boolean value) {
        if (this.toggled == value) return;
        this.toggled = value;
        if (value) {
            onEnable();
        } else {
            onDisable();
        }
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onTick() {
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public boolean isToggled() {
        return toggled;
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }
}
