package dev.myhelper.feature;

import dev.myhelper.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffects;

public class AutoSprint {
    public static void tick(MinecraftClient client) {
        if (!ModConfig.get().autoSprint) return;

        if (client.player == null || client.currentScreen != null) return;

        // forward pressed, not sneaking, not swimming, not using item, not flying, hunger > 6, no blindness
        if (client.options.keyForward.isPressed()
                && !client.player.isSneaking()
                && !client.player.isTouchingWater()
                && !client.player.isUsingItem()
                && !client.player.abilities.flying
                && client.player.getHungerManager().getFoodLevel() > 6
                && !client.player.hasStatusEffect(StatusEffects.BLINDNESS)) {
            client.player.setSprinting(true);
        }
    }
}
