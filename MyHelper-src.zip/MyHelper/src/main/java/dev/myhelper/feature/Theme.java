package dev.myhelper.feature;

public enum Theme {
    FIRE("Огненный", 0xFFE53935, 0xFFB71C1C),
    MAGENTA("Малиновый", 0xFFD81B60, 0xFF880E4F),
    MARINE("Морской", 0xFF00ACC1, 0xFF006064),
    INTERGALACTIC("Intergalactic", 0xFF7B1FA2, 0xFF4A148C);

    private final String displayName;
    private final int primaryColor;
    private final int secondaryColor;

    Theme(String displayName, int primaryColor, int secondaryColor) {
        this.displayName = displayName;
        this.primaryColor = primaryColor;
        this.secondaryColor = secondaryColor;
    }

    public String getDisplayName() {
        return displayName;
    }

    public int getPrimaryColor() {
        return primaryColor;
    }

    public int getSecondaryColor() {
        return secondaryColor;
    }
}
