package dev.myhelper.feature;

import dev.myhelper.config.ModConfig;
import net.minecraft.client.MinecraftClient;

public class Zoom {
    private static boolean active = false;
    private static double prevFov = 70.0;

    public static void tick(MinecraftClient client, boolean keyPressed) {
        if (!ModConfig.get().zoomEnabled) {
            if (active) {
                // restore
                active = false;
            }
            return;
        }

        if (keyPressed && !active) {
            active = true;
            if (client.options != null) {
                prevFov = client.options.fov;
            }
        } else if (!keyPressed && active) {
            active = false;
            if (client.options != null) {
                client.options.fov = prevFov;
            }
        }

        if (active && client.options != null) {
            double factor = ModConfig.get().zoomFactor;
            client.options.fov = prevFov * factor;
        }
    }

    public static boolean isActive() {
        return active;
    }

    public static double getZoomFactor() {
        return ModConfig.get().zoomFactor;
    }
}
