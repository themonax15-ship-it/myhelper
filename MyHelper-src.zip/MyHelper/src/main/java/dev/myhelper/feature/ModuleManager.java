package dev.myhelper.feature;

import dev.myhelper.config.ModConfig;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // Combat
        modules.add(new Module("Triggerbot", "Combat", 0));
        modules.add(new Module("Backtrack", "Combat", 0));
        modules.add(new Module("TargetStrafe", "Combat", 0));

        // Player
        modules.add(new Module("AutoTotem", "Player", 0));
        modules.add(new Module("AutoGapple", "Player", 0));
        modules.add(new AutoSprintModule());
        modules.add(new Module("Sprint", "Player", 0));

        // Visuals
        modules.add(new TargetESP());
        modules.add(new Module("Tracers", "Visuals", 0));
        modules.add(new Module("ViewModel", "Visuals", 0));
        modules.add(new ZoomModule());

        // Misc
        modules.add(new Module("Timer", "Misc", 0));
        modules.add(new Module("Velocity", "Misc", 0));

        // restore states from config
        ModConfig cfg = ModConfig.get();
        for (Module m : modules) {
            Boolean saved = cfg.modules.get(m.getName());
            if (saved != null) {
                m.setToggled(saved);
            }
        }
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> getModulesByCategory(String category) {
        List<Module> filtered = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory().equalsIgnoreCase(category)) {
                filtered.add(m);
            }
        }
        return filtered;
    }

    public Module getByName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) {
                return m;
            }
        }
        return null;
    }

    public void tick() {
        for (Module m : modules) {
            if (m.isToggled()) {
                m.onTick();
            }
        }
    }

    public void saveStates() {
        ModConfig cfg = ModConfig.get();
        cfg.modules.clear();
        for (Module m : modules) {
            cfg.modules.put(m.getName(), m.isToggled());
        }
        cfg.save();
    }
}
