package dev.myhelper.feature;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.myhelper.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Matrix4f;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

/**
 * TargetESP — красивый ESP игроков + 3D-кольцо над инвизами.
 *
 * Обычный игрок: полупрозрачный бокс + outline (бирюзовый, при уроне — красный).
 * Инвиз: белое 3D-кольцо над головой.
 * Инвиз + урон (hurtTime > 0): кольцо становится красным.
 */
public class TargetESP extends Module {

    private static final int CIRCLE_SEGMENTS = 64;
    private static final float CIRCLE_RADIUS = 0.52f;
    private static final float CIRCLE_Y_OFFSET = 0.32f;

    public TargetESP() {
        super("TargetESP", "Visuals", 0);
    }

    @Override
    public void onEnable() {
        ModConfig.get().modules.put(getName(), true);
        ModConfig.get().save();
    }

    @Override
    public void onDisable() {
        ModConfig.get().modules.put(getName(), false);
        ModConfig.get().save();
    }

    /**
     * Вызывается из WorldRendererMixin.
     * Используем собственный MatrixStack + позицию камеры, чтобы не зависеть от состояния стека.
     */
    public static void render(float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.gameRenderer == null) return;

        if (dev.myhelper.MyHelperClient.moduleManager == null) return;
        Module mod = dev.myhelper.MyHelperClient.moduleManager.getByName("TargetESP");
        if (mod == null || !mod.isToggled()) return;

        Camera camera = client.gameRenderer.getCamera();
        Vec3d camPos = camera.getPos();

        MatrixStack matrices = new MatrixStack();
        // Камера уже применила view-matrix через OpenGL в 1.16;
        // мы рисуем в world-space относительно камеры.
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);

        RenderSystem.pushMatrix();
        RenderSystem.multMatrix(matrices.peek().getModel());

        RenderSystem.disableTexture();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.lineWidth(2.2f);

        Matrix4f matrix = matrices.peek().getModel();

        for (PlayerEntity player : client.world.getPlayers()) {
            if (player == client.player) continue;
            if (!player.isAlive()) continue;

            double x = MathHelper.lerp(tickDelta, player.lastRenderX, player.getX());
            double y = MathHelper.lerp(tickDelta, player.lastRenderY, player.getY());
            double z = MathHelper.lerp(tickDelta, player.lastRenderZ, player.getZ());

            float height = player.getHeight();
            float width = player.getWidth();

            boolean invisible = player.isInvisible() || player.isInvisibleTo(client.player);
            boolean damaged = player.hurtTime > 0;

            if (invisible) {
                float r, g, b, a;
                if (damaged) {
                    r = 1.00f; g = 0.12f; b = 0.12f; a = 0.95f; // красный
                } else {
                    r = 1.00f; g = 1.00f; b = 1.00f; a = 0.92f; // белый
                }

                double cy = y + height + CIRCLE_Y_OFFSET;
                drawFancyCircle(matrix, x, cy, z, CIRCLE_RADIUS, r, g, b, a);
            } else {
                Box box = new Box(
                        x - width / 2.0, y,
                        z - width / 2.0,
                        x + width / 2.0, y + height,
                        z + width / 2.0
                );

                float r, g, b, aOutline, aFill;
                if (damaged) {
                    r = 1.00f; g = 0.22f; b = 0.22f;
                    aOutline = 0.90f; aFill = 0.14f;
                } else {
                    r = 0.20f; g = 0.90f; b = 1.00f;
                    aOutline = 0.80f; aFill = 0.11f;
                }

                drawBoxOutline(matrix, box, r, g, b, aOutline);
                drawBoxFilled(matrix, box, r, g, b, aFill);
            }
        }

        RenderSystem.lineWidth(1.0f);
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        RenderSystem.enableTexture();
        RenderSystem.popMatrix();
    }

    /** Красивое 3D-кольцо: два контура + рёбра + «лучи» вниз. */
    private static void drawFancyCircle(Matrix4f matrix, double cx, double cy, double cz,
                                        float radius, float r, float g, float b, float a) {
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();
        float h = 0.055f; // высота «обода»

        // нижнее кольцо
        buf.begin(GL11.GL_LINE_LOOP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < CIRCLE_SEGMENTS; i++) {
            float ang = (float) (2 * Math.PI * i / CIRCLE_SEGMENTS);
            float dx = MathHelper.cos(ang) * radius;
            float dz = MathHelper.sin(ang) * radius;
            buf.vertex(matrix, (float) (cx + dx), (float) cy, (float) (cz + dz)).color(r, g, b, a).next();
        }
        tess.draw();

        // верхнее кольцо
        buf.begin(GL11.GL_LINE_LOOP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < CIRCLE_SEGMENTS; i++) {
            float ang = (float) (2 * Math.PI * i / CIRCLE_SEGMENTS);
            float dx = MathHelper.cos(ang) * radius;
            float dz = MathHelper.sin(ang) * radius;
            buf.vertex(matrix, (float) (cx + dx), (float) (cy + h), (float) (cz + dz)).color(r, g, b, a * 0.75f).next();
        }
        tess.draw();

        // внутреннее кольцо (тоньше)
        float r2 = radius * 0.78f;
        buf.begin(GL11.GL_LINE_LOOP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < CIRCLE_SEGMENTS; i++) {
            float ang = (float) (2 * Math.PI * i / CIRCLE_SEGMENTS);
            float dx = MathHelper.cos(ang) * r2;
            float dz = MathHelper.sin(ang) * r2;
            buf.vertex(matrix, (float) (cx + dx), (float) (cy + h * 0.5f), (float) (cz + dz)).color(r, g, b, a * 0.55f).next();
        }
        tess.draw();

        // вертикальные рёбра (3D-обод)
        buf.begin(GL11.GL_LINES, VertexFormats.POSITION_COLOR);
        int ribs = 16;
        for (int i = 0; i < ribs; i++) {
            float ang = (float) (2 * Math.PI * i / ribs);
            float dx = MathHelper.cos(ang) * radius;
            float dz = MathHelper.sin(ang) * radius;
            buf.vertex(matrix, (float) (cx + dx), (float) cy, (float) (cz + dz)).color(r, g, b, a * 0.85f).next();
            buf.vertex(matrix, (float) (cx + dx), (float) (cy + h), (float) (cz + dz)).color(r, g, b, a * 0.55f).next();
        }
        tess.draw();

        // тонкие «столбики» вниз для объёма
        buf.begin(GL11.GL_LINES, VertexFormats.POSITION_COLOR);
        int pillars = 8;
        float pillarH = 0.20f;
        for (int i = 0; i < pillars; i++) {
            float ang = (float) (2 * Math.PI * i / pillars);
            float dx = MathHelper.cos(ang) * radius;
            float dz = MathHelper.sin(ang) * radius;
            buf.vertex(matrix, (float) (cx + dx), (float) (cy - pillarH), (float) (cz + dz)).color(r, g, b, a * 0.45f).next();
            buf.vertex(matrix, (float) (cx + dx), (float) cy, (float) (cz + dz)).color(r, g, b, a * 0.25f).next();
        }
        tess.draw();
    }

    private static void drawBoxOutline(Matrix4f matrix, Box box, float r, float g, float b, float a) {
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();

        float x1 = (float) box.minX, y1 = (float) box.minY, z1 = (float) box.minZ;
        float x2 = (float) box.maxX, y2 = (float) box.maxY, z2 = (float) box.maxZ;

        buf.begin(GL11.GL_LINES, VertexFormats.POSITION_COLOR);
        // bottom
        line(buf, matrix, x1, y1, z1, x2, y1, z1, r, g, b, a);
        line(buf, matrix, x2, y1, z1, x2, y1, z2, r, g, b, a);
        line(buf, matrix, x2, y1, z2, x1, y1, z2, r, g, b, a);
        line(buf, matrix, x1, y1, z2, x1, y1, z1, r, g, b, a);
        // top
        line(buf, matrix, x1, y2, z1, x2, y2, z1, r, g, b, a);
        line(buf, matrix, x2, y2, z1, x2, y2, z2, r, g, b, a);
        line(buf, matrix, x2, y2, z2, x1, y2, z2, r, g, b, a);
        line(buf, matrix, x1, y2, z2, x1, y2, z1, r, g, b, a);
        // verticals
        line(buf, matrix, x1, y1, z1, x1, y2, z1, r, g, b, a);
        line(buf, matrix, x2, y1, z1, x2, y2, z1, r, g, b, a);
        line(buf, matrix, x2, y1, z2, x2, y2, z2, r, g, b, a);
        line(buf, matrix, x1, y1, z2, x1, y2, z2, r, g, b, a);
        tess.draw();
    }

    private static void drawBoxFilled(Matrix4f matrix, Box box, float r, float g, float b, float a) {
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();

        float x1 = (float) box.minX, y1 = (float) box.minY, z1 = (float) box.minZ;
        float x2 = (float) box.maxX, y2 = (float) box.maxY, z2 = (float) box.maxZ;

        buf.begin(GL11.GL_QUADS, VertexFormats.POSITION_COLOR);
        // bottom
        quad(buf, matrix, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, r, g, b, a);
        // top
        quad(buf, matrix, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1, r, g, b, a);
        // sides
        quad(buf, matrix, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1, r, g, b, a);
        quad(buf, matrix, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2, r, g, b, a);
        quad(buf, matrix, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1, r, g, b, a);
        quad(buf, matrix, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2, r, g, b, a);
        tess.draw();
    }

    private static void line(BufferBuilder buf, Matrix4f m,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             float r, float g, float b, float a) {
        buf.vertex(m, x1, y1, z1).color(r, g, b, a).next();
        buf.vertex(m, x2, y2, z2).color(r, g, b, a).next();
    }

    private static void quad(BufferBuilder buf, Matrix4f m,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             float x3, float y3, float z3, float x4, float y4, float z4,
                             float r, float g, float b, float a) {
        buf.vertex(m, x1, y1, z1).color(r, g, b, a).next();
        buf.vertex(m, x2, y2, z2).color(r, g, b, a).next();
        buf.vertex(m, x3, y3, z3).color(r, g, b, a).next();
        buf.vertex(m, x4, y4, z4).color(r, g, b, a).next();
    }
}
