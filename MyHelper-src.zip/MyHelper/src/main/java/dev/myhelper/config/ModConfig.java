package dev.myhelper.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("myhelper.json");
    private static ModConfig instance;

    public boolean autoSprint = true;
    public boolean zoomEnabled = true;
    public double zoomFactor = 0.35;
    public String theme = "MARINE";

    // Module states (name -> enabled)
    public java.util.Map<String, Boolean> modules = new java.util.HashMap<>();

    public static ModConfig get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    public static ModConfig load() {
        if (Files.exists(FILE)) {
            try {
                String json = new String(Files.readAllBytes(FILE), StandardCharsets.UTF_8);
                ModConfig cfg = GSON.fromJson(json, ModConfig.class);
                if (cfg != null) {
                    if (cfg.modules == null) cfg.modules = new java.util.HashMap<>();
                    return cfg;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return new ModConfig();
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.write(FILE, GSON.toJson(this).getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
