package dev.myhelper.gui;

import dev.myhelper.config.ModConfig;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class MenuScreen extends Screen {
    private enum Tab {
        MOVEMENT("Движение"),
        CAMERA("Камера");

        final String title;
        Tab(String title) { this.title = title; }
    }

    private static final int PANEL_W = 380;
    private static final int PANEL_H = 220;
    private static final int SIDEBAR_W = 100;

    private static final int COL_BG = 0xE0101018;
    private static final int COL_SIDEBAR = 0xF0181824;
    private static final int COL_ACCENT = 0xFF7C5CFF;

    private static Tab selected = Tab.MOVEMENT;

    private final Screen parent;
    private int px, py;

    public MenuScreen(Screen parent) {
        super(new LiteralText("MyHelper"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        px = (width - PANEL_W) / 2;
        py = (height - PANEL_H) / 2;

        // Вкладки слева
        int ty = py + 34;
        for (Tab tab : Tab.values()) {
            String label = (tab == selected ? "> " : "") + tab.title;
            addButton(new ButtonWidget(px + 8, ty, SIDEBAR_W - 16, 20, new LiteralText(label), b -> {
                selected = tab;
                this.init(client, width, height);
            }));
            ty += 24;
        }

        // Содержимое вкладки
        int cx = px + SIDEBAR_W + 12;
        int cw = PANEL_W - SIDEBAR_W - 24;
        int cy = py + 34;
        ModConfig cfg = ModConfig.get();

        switch (selected) {
            case MOVEMENT:
                toggle(cx, cy, cw, "Авто-спринт", () -> cfg.autoSprint, v -> cfg.autoSprint = v);
                break;
            case CAMERA:
                toggle(cx, cy, cw, "Зум", () -> cfg.zoomEnabled, v -> cfg.zoomEnabled = v);
                addButton(new ZoomSlider(cx, cy + 24, cw));
                toggle(cx, cy + 48, cw, "Зум колесом мыши", () -> cfg.zoomScroll, v -> cfg.zoomScroll = v);
                toggle(cx, cy + 72, cw, "Плавная камера при зуме", () -> cfg.zoomSmoothCamera, v -> cfg.zoomSmoothCamera = v);
                break;
        }
    }

    private void toggle(int x, int y, int w, String label, BooleanSupplier get, Consumer<Boolean> set) {
        addButton(new ButtonWidget(x, y, w, 20, toggleText(label, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(toggleText(label, get.getAsBoolean()));
            ModConfig.save();
        }));
    }

    private static Text toggleText(String label, boolean on) {
        return new LiteralText(label + ": " + (on ? "§aВКЛ" : "§cВЫКЛ"));
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        renderBackground(matrices);

        fill(matrices, px, py, px + PANEL_W, py + PANEL_H, COL_BG);
        fill(matrices, px, py, px + SIDEBAR_W, py + PANEL_H, COL_SIDEBAR);
        fill(matrices, px, py, px + PANEL_W, py + 2, COL_ACCENT);

        drawCenteredText(matrices, textRenderer, title, px + SIDEBAR_W / 2, py + 12, 0xFFFFFF);
        drawTextWithShadow(matrices, textRenderer, new LiteralText(selected.title), px + SIDEBAR_W + 12, py + 12, COL_ACCENT);

        super.render(matrices, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        ModConfig.save();
        client.openScreen(parent);
    }

    /** Ползунок кратности зума (1.5x – 20x). */
    private static class ZoomSlider extends SliderWidget {
        private static final double MIN = 1.5, MAX = 20.0;

        ZoomSlider(int x, int y, int w) {
            super(x, y, w, 20, LiteralText.EMPTY, (ModConfig.get().zoomFactor - MIN) / (MAX - MIN));
            updateMessage();
        }

        private double factor() {
            return MIN + value * (MAX - MIN);
        }

        @Override
        protected void updateMessage() {
            setMessage(new LiteralText(String.format("Кратность зума: %.1fx", factor())));
        }

        @Override
        protected void applyValue() {
            ModConfig.get().zoomFactor = factor();
        }

        @Override
        public void onRelease(double mouseX, double mouseY) {
            super.onRelease(mouseX, mouseY);
            ModConfig.save();
        }
    }
}
