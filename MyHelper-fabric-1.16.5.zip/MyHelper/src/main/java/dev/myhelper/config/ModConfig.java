package dev.myhelper.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("myhelper.json");
    private static ModConfig instance = new ModConfig();

    // Движение
    public boolean autoSprint = true;

    // Камера / зум
    public boolean zoomEnabled = true;
    public boolean zoomScroll = true;
    public boolean zoomSmoothCamera = true;
    public double zoomFactor = 4.0; // 1.5 .. 20

    public static ModConfig get() {
        return instance;
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                String json = new String(Files.readAllBytes(FILE), StandardCharsets.UTF_8);
                ModConfig loaded = GSON.fromJson(json, ModConfig.class);
                if (loaded != null) instance = loaded;
            } else {
                save();
            }
        } catch (Exception e) {
            System.err.println("[MyHelper] Не удалось загрузить конфиг: " + e);
        }
    }

    public static void save() {
        try {
            Files.write(FILE, GSON.toJson(instance).getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.err.println("[MyHelper] Не удалось сохранить конфиг: " + e);
        }
    }
}
