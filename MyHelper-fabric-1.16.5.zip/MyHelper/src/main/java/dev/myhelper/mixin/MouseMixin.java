package dev.myhelper.mixin;

import dev.myhelper.config.ModConfig;
import dev.myhelper.feature.Zoom;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MouseMixin {
    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void myhelper$zoomScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (Zoom.isActive() && ModConfig.get().zoomScroll && vertical != 0) {
            Zoom.scroll(vertical);
            ci.cancel(); // не крутим хотбар
        }
    }
}
