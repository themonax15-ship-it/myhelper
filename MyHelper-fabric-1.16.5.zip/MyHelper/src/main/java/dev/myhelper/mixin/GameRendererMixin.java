package dev.myhelper.mixin;

import dev.myhelper.feature.Zoom;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void myhelper$zoomFov(Camera camera, float tickDelta, boolean changingFov,
                                  CallbackInfoReturnable<Double> cir) {
        double d = Zoom.divisor(tickDelta);
        if (d > 1.0001) {
            cir.setReturnValue(cir.getReturnValue() / d);
        }
    }
}
