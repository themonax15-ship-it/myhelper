package dev.myhelper.feature;

import dev.myhelper.config.ModConfig;
import net.minecraft.client.MinecraftClient;

public final class Zoom {
    private static boolean active;
    private static double prev = 1.0;
    private static double cur = 1.0;
    private static boolean weEnabledSmooth;
    private static boolean dirty;

    private Zoom() {}

    public static boolean isActive() {
        return active;
    }

    /** Вызывать каждый тик. */
    public static void tick(MinecraftClient client, boolean keyHeld) {
        ModConfig cfg = ModConfig.get();
        boolean want = cfg.zoomEnabled && keyHeld && client.currentScreen == null;

        if (want != active) {
            active = want;
            if (active) {
                if (cfg.zoomSmoothCamera && !client.options.smoothCameraEnabled) {
                    client.options.smoothCameraEnabled = true;
                    weEnabledSmooth = true;
                }
            } else {
                if (weEnabledSmooth) {
                    client.options.smoothCameraEnabled = false;
                    weEnabledSmooth = false;
                }
                if (dirty) {
                    ModConfig.save();
                    dirty = false;
                }
            }
        }

        double target = active ? cfg.zoomFactor : 1.0;
        prev = cur;
        cur += (target - cur) * 0.45;
        if (Math.abs(target - cur) < 0.001) cur = target;
    }

    /** Делитель FOV с интерполяцией между тиками. */
    public static double divisor(float tickDelta) {
        return prev + (cur - prev) * tickDelta;
    }

    /** Колесо мыши меняет кратность. */
    public static void scroll(double vertical) {
        ModConfig cfg = ModConfig.get();
        double f = cfg.zoomFactor * (vertical > 0 ? 1.15 : 1.0 / 1.15);
        cfg.zoomFactor = Math.max(1.5, Math.min(20.0, f));
        dirty = true;
    }
}
