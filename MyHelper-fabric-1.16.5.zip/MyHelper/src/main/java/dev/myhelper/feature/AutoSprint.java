package dev.myhelper.feature;

import dev.myhelper.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;

public final class AutoSprint {
    private AutoSprint() {}

    public static void tick(MinecraftClient client) {
        if (!ModConfig.get().autoSprint) return;
        ClientPlayerEntity p = client.player;
        if (p == null || client.currentScreen != null) return;

        if (client.options.keyForward.isPressed()
                && !p.isSprinting()
                && !p.isSneaking()
                && !p.hasVehicle()
                && !p.isUsingItem()
                && !p.horizontalCollision
                && p.getHungerManager().getFoodLevel() > 6
                && !p.hasStatusEffect(StatusEffects.BLINDNESS)) {
            p.setSprinting(true);
        }
    }
}
