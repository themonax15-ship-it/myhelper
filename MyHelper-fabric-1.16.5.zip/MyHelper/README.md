# MyHelper (Fabric 1.16.5)

Клиентский мод: авто-спринт, зум, меню настроек (Right Shift).

## Сборка
Нужен JDK 16 или 17.

    gradle wrapper --gradle-version 7.4.2   # один раз, если нет gradlew
    ./gradlew build                          # jar в build/libs/
    ./gradlew runClient                      # запуск для отладки

Или откройте папку в IntelliJ IDEA как Gradle-проект.

## Клавиши
- Right Shift — меню
- C (удерживать) — зум, колесо мыши меняет кратность
